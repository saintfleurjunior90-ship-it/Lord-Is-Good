# KOKIYOL Ayisyen – Authentic Haitian Donuts

Site de commande de **Lord Is Good Donuts** — *« Sharing Haitian Sweetness, One Bite at a Time. »*

> **État : étape 1 terminée (front-end).** La base de données et le paiement Stripe
> seront ajoutés aux étapes 2 et 3, après validation du propriétaire.

## Lancer le site en local

Il faut Node.js 20 ou plus récent.

```bash
npm run dev      # → http://localhost:3000
npm test         # tests de calcul des prix et de la livraison
```

Pour un simple aperçu, on peut aussi **double-cliquer sur `public/index.html`**.

## Structure

```
public/
  config.js            ← À MODIFIER : prix, livraison, taxe, moyens de paiement, coordonnées
  js/pricing.js        ← calcul sous-total / livraison / taxe / total (partagé navigateur + serveur)
  index.html           ← page principale
  conditions.html      ← conditions de vente / remboursement (TEXTE PROVISOIRE)
  css/style.css
  js/i18n.js           ← textes en créole, français, anglais
  js/app.js            ← panier en 3 étapes, validation, suivi, diaporama
  img/                 ← logo, photos (JPEG + WebP), favicon, image de partage
scripts/dev-server.js  ← serveur local sans dépendance (étape 1)
tests/pricing.test.js
```

## Modifier les prix ou la livraison

Tout est dans `public/config.js` → `products` et `shipping`. Le serveur (étape 3) recalculera
toujours les prix à partir de ce fichier : un prix modifié dans le navigateur n'a aucun effet.

## TODO à confirmer (recherchez « TODO » dans le code)

| Sujet | Fichier | Valeur actuelle |
|---|---|---|
| Frais de livraison : une fois par commande ou par article ? | `public/config.js` → `shipping.flatFee` | 6,23 $ une fois par commande |
| « Remarque » sur la livraison de la Petite boîte | `public/config.js` | inconnue |
| Boîte familiale → livraison gratuite pour toute la commande | `public/config.js` → `freeIfAnyFreeShippingProduct` | oui |
| Zone de livraison | `public/config.js` → `allowedCountries` | États-Unis |
| Adresse de retrait | `public/config.js` → `business.pickupAddress` | vide |
| Numéros Zelle / Cash App / MonCash / NatCash | `public/config.js` → `payments.manual` | vides (avertissement affiché) |
| Taxe de vente | `public/config.js` → `tax` | désactivée |
| Nom de domaine | `public/index.html` (balises `VOTRE-DOMAINE`) | à remplacer |
| Texte des conditions de vente | `public/conditions.html` | provisoire |
